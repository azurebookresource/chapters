/*
 * This program is based on a program
 * that calculates the maximum closing price of stocks 
 * The original program is available at
 * https://www.hadoopinrealworld.com/
 */

//reduce program
 import java.io.IOException;

 import org.apache.hadoop.io.FloatWritable;
 import org.apache.hadoop.io.Text;
 import org.apache.hadoop.mapreduce.Reducer;

 public class TemperatureReducer
 extends Reducer<Text, FloatWritable, Text, FloatWritable>
 {
	 @Override
	 public void reduce(Text airport, Iterable<FloatWritable> temperatures, Context context)
			 throws IOException, InterruptedException
	 {
		 float sum = 0;
		 int count = 0;
		 
		 //search the list and add all temperatures of the same airport
		 for (FloatWritable temperature : temperatures) {
			 sum = sum + temperature.get();
			 count = count + 1;
		 }	 
		 float result = sum/count;
		 
		 //output airport code and the average temperature
		 context.write(airport, new FloatWritable(result));
	 }
 }