//control program

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class Price
{
	public static void main(String[] args) throws Exception
	{
		if (args.length != 2)
		{
			System.err.println("Usage: Price <input path> <output path>");
			System.exit(-1);
		}

		Job myjob = new Job();
		myjob.setJarByClass(Price.class);
		myjob.setJobName("MaximumPrice");

		FileInputFormat.addInputPath(myjob, new Path(args[0]));
		FileOutputFormat.setOutputPath(myjob, new Path(args[1]));
		
	    myjob.setInputFormatClass(TextInputFormat.class);
	    myjob.setOutputFormatClass(TextOutputFormat.class);

		myjob.setMapperClass(PriceMapper.class);
		myjob.setReducerClass(PriceReducer.class);

		myjob.setOutputKeyClass(Text.class);
		myjob.setOutputValueClass(FloatWritable.class);

		System.exit(myjob.waitForCompletion(true) ? 0 : 1);
	}
}
