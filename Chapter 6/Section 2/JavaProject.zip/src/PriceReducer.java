//reduce program
 import java.io.IOException;

 import org.apache.hadoop.io.FloatWritable;
 import org.apache.hadoop.io.Text;
 import org.apache.hadoop.mapreduce.Reducer;

 public class PriceReducer
 extends Reducer<Text, FloatWritable, Text, FloatWritable>
 {
	 @Override
	 public void reduce(Text ticker, Iterable<FloatWritable> values, Context context)
			 throws IOException, InterruptedException
	 {
		 float result = Float.MIN_VALUE;
		 
		 //search the list and assign the maximum price to result
		 for (FloatWritable value : values) {
			 result = Math.max(result, value.get());
		 }
		 
		 //output ticker and the maximum price
		 context.write(ticker, new FloatWritable(result));
	 }
 }