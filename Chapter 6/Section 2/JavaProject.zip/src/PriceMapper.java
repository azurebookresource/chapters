//map program

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class PriceMapper extends Mapper<LongWritable, Text, Text, FloatWritable>
{
	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException
	{
		// one line (record)
		String record = value.toString(); 
		
		// split one record into three fields: [ticker, date, price]
		String[] fields = record.split(","); 
		
		// retrieve ticker from the first column
		String ticker = fields[0]; 
		
		// retrieve price from the third column
		Float price = Float.parseFloat(fields[2]);
		
		//output a (key, value) pair: (ticker, price)
		context.write(new Text(ticker), new FloatWritable(price));
	}
}